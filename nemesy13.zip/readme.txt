Version 1.3 - bugs fixed....now should work better

....

short description: this program generate random packets (protocol,port,etc...) of course the source ip is spoofed (random progressive generation)... so dont worry packet as much u want.

help: well victim ip doesnt need a description, packets... as number put 0 if u want to packet until u click on "halt" otherwise chose the number of packets u want to send, as size put the size of the single packet, if u want random size put 'r' before the number, the number will be the size limit, as delay ... put the delay between the send of each packet...have fun packet monkeys (lmao)...peace out.

syntax: nemesy.exe /packet <ip> <npacket> <szpacket> <delay>

contact me at: lucisfero@twlc.net

url: http://www.twlc.net


LucisFero ./twlc
#twlc@undernet


eof